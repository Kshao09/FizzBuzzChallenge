/*
@ Kenny Shao
Title: FizzBuzzChallenge
Semester: COP-2210 Fall 2021
Professor's Name: Prof. Charters

This program loops through all the numbers between 1 and 100 and prints out the numbers divisible by 3 and 5
and replaces the numbers with fizz and buzz respectively. For the numbers that are divisible by 3 and 5, print out
fizz buzz. Then print out all the other numbers that are neither divisible by 3 or 5. For every fizz buzz,
we output the number divided by 3 and 5 and store those numbers in num1 and num2. Then we square the numbers and cast
it into an int.
 */
public class FizzBuzz {
    public static void fizzBuzz() {
        int num1 = 0, num2 = 0, sum = 0;
        for (int i = 1; i <= 100; i++) {
            if (i % 5 == 0 && i % 3 == 0) {
                System.out.print("fizz buzz ");
                num1 = i / 5;
                num2 = i / 3;
                sum = num1 + num2;
                System.out.println((int)Math.pow(sum, 2));
            } else if (i % 3 == 0) {
                System.out.println("fizz");
            } else if (i % 5 == 0) {
                System.out.println("buzz");
            } else {
                System.out.println(i);
            }
        }

    }

    public static void main(String[] args) {
        fizzBuzz();
    }
}
